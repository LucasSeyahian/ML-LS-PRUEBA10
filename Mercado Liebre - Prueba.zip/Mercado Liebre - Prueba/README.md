# Mercado-Liebre
Proyecto E-commerce
Práctica integradora realizado en el marco de Digital House.
Creación de un e-commerce siguiendo los requerimientos del cliente.

https://web-production-0ade.up.railway.app/
